---
name: Bug Report / Feature Request
about: Report a bug or suggest an improvement
---

## Type
- [ ] Bug report
- [ ] Feature request
- [ ] Question

## Phase
- [ ] Phase 1 (phase1.html)
- [ ] Phase 2 (phase2.html)
- [ ] Phase 3 (phase3.html)
- [ ] All phases / Landing page

## Browser & OS
<!-- e.g. Chrome 124 on macOS 14 -->

## Description
<!-- Clear description of the bug or feature -->

## Steps to Reproduce (bugs only)
1. 
2. 
3. 

## Expected Behavior


## Actual Behavior


## Additional Context
<!-- Screenshots, console errors, etc. -->
